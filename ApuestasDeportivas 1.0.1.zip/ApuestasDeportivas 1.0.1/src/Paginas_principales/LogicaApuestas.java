/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Paginas_principales;

/**
 *
 * @author Victor ramos
 */

import java.util.Random;

public class LogicaApuestas {
    private double saldo; // Saldo actual
    private Random random; // Para generar resultados aleatorios

    // Constructor
    public LogicaApuestas(double saldoInicial) {
        this.saldo = saldoInicial;
        this.random = new Random();
    }

    // Método para procesar la apuesta
    public double procesarApuesta(double cantidadApostar, String equipoSeleccionado) {
        // Validación básica
        if (cantidadApostar > saldo) {
            throw new IllegalArgumentException("No tienes saldo suficiente para apostar.");
        }

        // Generar aleatoriamente al equipo ganador
        String equipoGanador = random.nextBoolean() ? "Team A" : "Team B";

        // Determinar si el usuario gana o pierde
        double ganancias = 0;
        if (equipoSeleccionado.equals(equipoGanador)) {
            ganancias = cantidadApostar * 2; // Gana el doble de lo apostado
        } else {
            ganancias = -cantidadApostar; // Pierde lo apostado
        }

        // Actualizar saldo
        saldo += ganancias;
        return ganancias; // Devuelve solo la ganancia o pérdida de esta apuesta
    }

    public double getSaldo() {
        return saldo;
    }
}

